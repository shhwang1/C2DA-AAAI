import numpy as np


def inv_lr_scheduler(param_lr, optimizer, iter_num, gamma=0.0001,
                     power=0.75, init_lr=0.001):
    """Decay learning rate by a factor of 0.1 every lr_decay_epoch epochs."""
    lr = init_lr * (1 + gamma * iter_num) ** (- power)
    i = 0
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr * param_lr[i]
        i += 1
    return optimizer


def calc_coeff(iter_num, high=1.0, low=0.0, alpha=10.0, max_iter=10000.0):
    return np.float(2.0 * (high - low) /
                    (1.0 + np.exp(- alpha * iter_num / max_iter)) -
                    (high - low) + low)


def adjust_learning_rate(param_lr,optimizer, epoch,initial_lr, lr_type,epochs,default_start=0):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    if lr_type == 'cos':
        import math
        lr = 0.5 * initial_lr * (1 + math.cos(math.pi * (epoch - default_start) / epochs))
    else:
        raise NotImplementedError
    i = 0
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr * param_lr[i]
        i += 1
    return optimizer